# Android ফোন থেকে Remotion MP4 রেন্ডার (টার্মিনাল ছাড়া)

এই প্রজেক্টে `.github/workflows/render.yml` আগে থেকেই আছে। GitHub Actions ব্যবহার করে ক্লাউডে রেন্ডার হবে; Android-এ Termux বা Codespaces টার্মিনাল লাগবে না।

## একবারের সেটআপ
1. GitHub-এ একটি নতুন **Public বা Private repository** তৈরি করুন।
2. এই ZIP-টি ফোনে Extract করুন। ZIP ফাইলটি সরাসরি রিপোজিটরিতে আপলোড করবেন না—ভেতরের `brilliant-connect-motion` ফোল্ডারের ফাইলগুলো আপলোড করতে হবে, `.github` ফোল্ডারসহ।
3. GitHub repository-তে **Add file → Upload files** খুলে project files/folders আপলোড করে commit করুন। মোবাইল ব্রাউজারে hidden `.github` ফোল্ডার আপলোড করা কঠিন হলে GitHub Desktop/কম্পিউটার লাগতে পারে; বিকল্পভাবে GitHub-এর web editor দিয়ে workflow ফাইল তৈরি করুন।
4. Repository → **Actions** খুলুন। যদি workflow disabled থাকে, **I understand my workflows, go ahead and enable them** চাপুন।

## প্রতিবার রেন্ডার
1. Repository → **Actions** → **Render Remotion Video** খুলুন।
2. **Run workflow** চাপুন → `Main` রাখুন → আবার **Run workflow** চাপুন।
3. কাজ শেষ হলে সবুজ ✓ দেখাবে। রান খুলে নিচে **Artifacts** থেকে `brilliant-connect-video` ডাউনলোড করুন। ZIP artifact খুললে `video.mp4` পাবেন।

## গুরুত্বপূর্ণ
- GitHub Actions-এর ব্যবহারের সীমা/খরচ অ্যাকাউন্ট ও repository-র ধরন অনুযায়ী বদলাতে পারে।
- Artifact 7 দিন পর মুছে যাবে।
- Render job ব্যর্থ হলে Actions run-এর error log দেখতে হবে।
- এটি আলাদা ওয়েব প্যানেল নয়; GitHub-এর browser UI-তে থাকা Run workflow বোতামই রেন্ডার শুরু করে।
